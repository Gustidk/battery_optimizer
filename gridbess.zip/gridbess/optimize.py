"""
Battery schedule optimisation -- the same formulations as the original
control/battery_optimizer.py (sensitivity model) and
control/piecewise_optimizer.py (piecewise linear model), but with sparse
matrices (a full year fits in a few MB) and solvers that also run in the
browser: HiGHS (highspy) for the LPs, Clarabel for the QPs.

Variables: x = [discharge (T) | charge (T) | soc (T) | peak (L)]
"""
import numpy as np
import scipy.sparse as sp


class OptimisationError(RuntimeError):
    pass


# ----------------------------------------------------------------------- solvers
LP_OPTIONS = {}


def solve_lp(c, A_ub, b_ub, A_eq, b_eq, lb, ub, options=None):
    import highspy
    inf = highspy.kHighsInf
    A = sp.vstack([A_eq, A_ub], format="csc")
    lo = np.r_[b_eq, np.full(A_ub.shape[0], -inf)]
    hi = np.r_[b_eq, b_ub]
    h = highspy.Highs()
    h.setOptionValue("output_flag", False)
    for k, v in {**LP_OPTIONS, **(options or {})}.items():
        h.setOptionValue(k, v)
    lp = highspy.HighsLp()
    lp.num_col_ = len(c); lp.num_row_ = A.shape[0]
    lp.col_cost_ = np.asarray(c, float)
    lp.col_lower_ = np.where(np.isfinite(lb), lb, -inf)
    lp.col_upper_ = np.where(np.isfinite(ub), ub, inf)
    lp.row_lower_ = lo; lp.row_upper_ = hi
    lp.a_matrix_.format_ = highspy.MatrixFormat.kColwise
    lp.a_matrix_.start_ = A.indptr; lp.a_matrix_.index_ = A.indices; lp.a_matrix_.value_ = A.data
    h.passModel(lp)
    h.run()
    status = h.modelStatusToString(h.getModelStatus())
    if status != "Optimal":
        raise OptimisationError(f"The LP solver stopped with status '{status}'.")
    return np.array(h.getSolution().col_value)


def solve_qp(P_diag_idx, P_diag_val, q, A_ub, b_ub, A_eq, b_eq, lb, ub):
    """min 0.5 x'Px + q'x with diagonal P (only on given indices)."""
    import clarabel
    n = len(q)
    P = sp.csc_matrix((P_diag_val, (P_diag_idx, P_diag_idx)), shape=(n, n))
    I = sp.identity(n, format="csc")
    fu = np.isfinite(ub); fl = np.isfinite(lb)
    A = sp.vstack([A_eq, A_ub, I[fu], -I[fl]], format="csc")
    b = np.r_[b_eq, b_ub, ub[fu], -lb[fl]]
    cones = [clarabel.ZeroConeT(A_eq.shape[0]), clarabel.NonnegativeConeT(A.shape[0] - A_eq.shape[0])]
    s = clarabel.DefaultSettings()
    s.verbose = False
    s.max_iter = 200
    sol = clarabel.DefaultSolver(P, np.asarray(q, float), A, b, cones, s).solve()
    st = str(sol.status)
    if "Solved" not in st:          # Solved or AlmostSolved
        raise OptimisationError(f"The QP solver stopped with status '{st}'.")
    return np.array(sol.x)


def solve_conic(c, A_ub, b_ub, A_eq, b_eq, lb, ub, soc=None):
    """min c'x  s.t. A_eq x = b_eq, A_ub x <= b_ub, lb <= x <= ub and, optionally,
    sqrt(b0^2) >= ||-A_soc x||, written as the second-order cone  s = b_soc - A_soc x  in SOC (Clarabel)."""
    import clarabel
    n = len(c)
    I = sp.identity(n, format="csc")
    fu = np.isfinite(ub); fl = np.isfinite(lb)
    blocks = [A_eq, A_ub, I[fu], -I[fl]]
    b = [b_eq, b_ub, ub[fu], -lb[fl]]
    cones = [clarabel.ZeroConeT(A_eq.shape[0])]
    nn = A_ub.shape[0] + int(fu.sum()) + int(fl.sum())
    cones.append(clarabel.NonnegativeConeT(nn))
    if soc is not None:
        blocks.append(soc[0]); b.append(soc[1]); cones.append(clarabel.SecondOrderConeT(soc[0].shape[0]))
    A = sp.vstack(blocks, format="csc")
    s = clarabel.DefaultSettings(); s.verbose = False; s.max_iter = 300
    sol = clarabel.DefaultSolver(sp.csc_matrix((n, n)), np.asarray(c, float), A, np.concatenate(b), cones, s).solve()
    st = str(sol.status)
    if "Solved" not in st:
        raise OptimisationError(f"The solver stopped with status '{st}'.")
    return np.array(sol.x)


# ------------------------------------------------------------------ building blocks
def soc_equations(T, n, battery_mwh, eta_c, eta_d, soc_init_frac, dt_h):
    """soc[t] - soc[t-1] - eta_c*dt*c[t] + dt/eta_d*d[t] = 0, cyclic: soc[T-1] = soc0."""
    soc0 = soc_init_frac * battery_mwh
    t = np.arange(T)
    rows = np.r_[t, t, t, t[1:], T]
    cols = np.r_[2 * T + t, T + t, t, 2 * T + t[1:] - 1, 3 * T - 1]
    vals = np.r_[np.ones(T), np.full(T, -eta_c * dt_h), np.full(T, dt_h / eta_d), -np.ones(T - 1), 1.0]
    A = sp.csc_matrix((vals, (rows, cols)), shape=(T + 1, n))
    b = np.zeros(T + 1); b[0] = soc0; b[T] = soc0
    return A, b


def element_weights(net, weight_line, weight_trafo, element_weights=None):
    w = np.array([weight_trafo if e[0] == "trafo" else weight_line for e in net.elements], float)
    if element_weights:
        for k, e in enumerate(net.elements):
            key = f"{e[0]}:{e[1]}"
            if key in element_weights:
                w[k] = float(element_weights[key])
    return w


def _unpack(x, T, L):
    return x[:T], x[T:2 * T], x[2 * T:3 * T], x[3 * T:3 * T + L]


# ------------------------------------------- second priority: profit (lexicographic stage 2)
def grid_value(objective, peaks, weights):
    """The grid-friendliness objective of a vector of element peaks (the same quantity the first stage minimises)."""
    p = np.asarray(peaks, float)
    return float(p.mean()) if objective == "minmax" else float(np.sum(weights * p * p))


def priority_stage(objective, A_ub, b_ub, A_eq, b_eq, peak_lb, x1, pk0, bat, weights, lex, mode_tol=1e-3):
    """Stage 2 of the lexicographic optimisation. Stage 1 (x1) found the best grid-friendliness f*.
    Here the profit is maximised, subject to the grid objective staying at or below
        cap = f0 - priority * (f0 - f*)
    with f0 the value without battery and priority between 0 and 1 (1 = keep all of the grid benefit,
    0.9 = give up 10 % of it). Information about both stages goes into lex['info'].
    Same variables as stage 1: x = [discharge | charge | soc | peak]."""
    T = (len(x1) - len(peak_lb)) // 3
    L = len(peak_lb); n = 3 * T + L; dt = bat["dt_h"]
    price = np.asarray(lex["price"], float); tc = float(lex.get("throughput_cost", 0.0))
    prio = min(1.0, max(0.0, float(lex["priority_pct"]) / 100.0))
    f0 = grid_value(objective, pk0, weights); fs = grid_value(objective, x1[3 * T:], weights)
    red_max = max(f0 - fs, 0.0)
    cap_nominal = f0 - prio * red_max
    slack = 1e-4 * red_max + 1e-9 * max(abs(f0), 1.0)           # keeps the full-priority case feasible
    cap = cap_nominal + slack
    c = np.zeros(n)
    c[:T] = -price * dt + tc * dt
    c[T:2 * T] = price * dt + tc * dt
    c[3 * T:] = 1e-4 * (1.0 / L if objective == "minmax" else 0.0)      # tie-break: low peaks among equally profitable plans
    A_ub2, b_ub2, soc = A_ub, b_ub, None
    if prio > 0:
        if objective == "minmax":
            row = sp.csc_matrix((np.full(L, 1.0 / L), (np.zeros(L, int), 3 * T + np.arange(L))), shape=(1, n))
            A_ub2 = sp.vstack([A_ub, row], format="csc"); b_ub2 = np.r_[b_ub, cap]
        else:
            sw = np.sqrt(np.maximum(weights, 0.0))
            A_soc = sp.vstack([sp.csc_matrix((1, n)), sp.csc_matrix((-sw, (np.arange(L), 3 * T + np.arange(L))), shape=(L, n))], format="csc")
            soc = (A_soc, np.r_[np.sqrt(max(cap, 0.0)), np.zeros(L)])

    def one_pass(max_d, max_c):
        ub = np.r_[max_d, max_c, np.full(T, bat["mwh"]), np.full(L, np.inf)]
        lb = np.r_[np.zeros(3 * T), peak_lb]
        return solve_conic(c, A_ub2, b_ub2, A_eq, b_eq, lb, ub, soc)

    full = np.full(T, bat["mw"])
    x = one_pass(full, full)
    net = x[:T] - x[T:2 * T]
    try:
        x = one_pass(np.where(net > mode_tol, bat["mw"], 0.0), np.where(net < -mode_tol, bat["mw"], 0.0))
    except OptimisationError:
        pass                                                      # keep the free solution
    s1 = x1[:T] - x1[T:2 * T]; s2 = x[:T] - x[T:2 * T]
    rev = lambda s: float(np.sum(price * s) * dt - tc * np.sum(np.abs(s)) * dt)
    lex["info"] = {
        "priority_pct": float(lex["priority_pct"]), "objective": objective,
        "model_value_without_battery": f0, "model_value_stage1": fs, "model_value_stage2": grid_value(objective, x[3 * T:], weights),
        "model_reduction_stage1_pct": float(100 * red_max / f0) if f0 > 1e-12 else 0.0,
        "model_reduction_stage2_pct": float(100 * (f0 - grid_value(objective, x[3 * T:], weights)) / f0) if f0 > 1e-12 else 0.0,
        "revenue_stage1": rev(s1), "revenue_stage2": rev(s2),
    }
    return x


# --------------------------------------------------- sensitivity (tangent) model
def sensitivity_rows(baseline, s_d, s_c, mw):
    """peak[l] >= baseline[t,l] + s_d[t,l]*d[t] + s_c[t,l]*c[t]   ->   A_ub x <= b_ub."""
    T, L = baseline.shape
    s_d = np.broadcast_to(s_d, (T, L)); s_c = np.broadcast_to(s_c, (T, L))
    n = 3 * T + L
    # Exact row elimination: row (t,l) can never bind if the highest value it can take
    # (battery at full power in its worst direction) is below the lowest value some other
    # hour of the same element is guaranteed to have. Peak[l] is >= that value anyway.
    hi = baseline + (np.maximum(s_d, 0) + np.maximum(s_c, 0)) * mw
    lo = baseline + (np.minimum(s_d, 0) + np.minimum(s_c, 0)) * mw
    keep = hi > lo.max(axis=0)[None, :] - 1e-9
    tt, ll = np.nonzero(keep)
    nr = len(tt)
    r = np.arange(nr)
    A = sp.csc_matrix((np.r_[-np.ones(nr), s_d[tt, ll], s_c[tt, ll]],
                       (np.r_[r, r, r], np.r_[3 * T + ll, tt, T + tt])), shape=(nr, n))
    return A, -baseline[tt, ll]



def optimise_sensitivity(objective, baseline, s_d, s_c, bat, weights=None, lex=None):
    """objective 'minmax' (LP, objective 1) or 'quadratic_peak' (QP, objective 3).
    With lex (price, priority_pct, throughput_cost) the profit is optimised second, see priority_stage."""
    T, L = baseline.shape
    n = 3 * T + L
    A_eq, b_eq = soc_equations(T, n, bat["mwh"], bat["eta_c"], bat["eta_d"], bat["soc_init"], bat["dt_h"])
    A_ub, b_ub = sensitivity_rows(baseline, s_d, s_c, bat["mw"])
    ub = np.r_[np.full(2 * T, bat["mw"]), np.full(T, bat["mwh"]), np.full(L, np.inf)]
    if objective == "minmax":
        lb = np.r_[np.zeros(3 * T), np.full(L, -np.inf)]
        c = np.zeros(n); c[3 * T:] = 1.0 / L
        x = solve_lp(c, A_ub, b_ub, A_eq, b_eq, lb, ub)
    else:
        lb = np.zeros(n)
        x = solve_qp(np.arange(3 * T, n), 2.0 * weights, np.zeros(n), A_ub, b_ub, A_eq, b_eq, lb, ub)
    if lex is not None:
        x = priority_stage(objective, A_ub, b_ub, A_eq, b_eq, lb[3 * T:], x, baseline.max(axis=0), bat, weights, lex)
    return _unpack(x, T, L)


# ---------------------------------------------------------- piecewise linear model
def piecewise_rows(table, levels, flat_tol=1e-3):
    """table: (T, K, L) AC loading at each power level. One row per chord:
    peak[l] >= intercept + slope*(d[t] - c[t]).  Flat hours only raise peak's floor."""
    T, K, L = table.shape
    n = 3 * T + L
    dp = np.diff(levels)
    slope = np.diff(table, axis=1) / dp[None, :, None]               # (T, K-1, L)
    icpt = table[:, :-1, :] - slope * levels[None, :-1, None]
    floor = np.zeros(L)
    rows, cols, vals, rhs = [], [], [], []
    nrow = 0
    for l in range(L):
        s_l = slope[:, :, l]
        flat = np.max(np.abs(s_l), axis=1) < flat_tol
        if flat.any():
            floor[l] = max(floor[l], float(table[flat, :, l].max()))
        act_all = np.nonzero(~flat)[0]
        if len(act_all) == 0:
            continue
        # exact row elimination (see sensitivity_rows): f_t(p) >= min over levels of the
        # table, so peak[l] >= max_t min_k table; a chord whose largest value on
        # [-mw, mw] is below that can never bind.
        guaranteed = max(float(table[:, :, l].min(axis=1).max()), floor[l])
        for k in range(K - 1):
            top = np.maximum(icpt[act_all, k, l] + slope[act_all, k, l] * levels[0],
                             icpt[act_all, k, l] + slope[act_all, k, l] * levels[-1])
            act = act_all[top > guaranteed - 1e-9]
            na = len(act)
            if na == 0:
                continue
            s = s_l[act, k]
            rr = nrow + np.arange(na)
            rows += [rr, rr, rr]; cols += [act, T + act, np.full(na, 3 * T + l)]
            vals += [s, -s, -np.ones(na)]
            rhs.append(-icpt[act, k, l])
            nrow += na
    if nrow:
        A = sp.csc_matrix((np.concatenate(vals), (np.concatenate(rows), np.concatenate(cols))), shape=(nrow, n))
        b = np.concatenate(rhs)
    else:
        A = sp.csc_matrix((0, n)); b = np.zeros(0)
    return A, b, floor


def optimise_piecewise(objective, table, levels, bat, weights=None,
                       eps_lp=1e-4, eps_qp=1e-2, mode_tol=1e-3, lex=None, baseline=None):
    """Two passes (as in the original): pass 1 free, pass 2 with each hour's
    mode (charge / discharge / idle) locked, so the model SOC equals the physical SOC."""
    T, K, L = table.shape
    n = 3 * T + L
    A_eq, b_eq = soc_equations(T, n, bat["mwh"], bat["eta_c"], bat["eta_d"], bat["soc_init"], bat["dt_h"])
    A_ub, b_ub, floor = piecewise_rows(table, levels)

    def one_pass(max_d, max_c):
        ub = np.r_[max_d, max_c, np.full(T, bat["mwh"]), np.full(L, np.inf)]
        if objective == "minmax":
            lb = np.r_[np.zeros(3 * T), floor]
            c = np.zeros(n); c[3 * T:] = 1.0 / L; c[:2 * T] = eps_lp
            # interior point (Clarabel) -- much faster than simplex for this large LP,
            # also in the browser; pass 2 removes any ambiguity in charge/discharge
            return solve_qp(np.zeros(0, int), np.zeros(0), c, A_ub, b_ub, A_eq, b_eq, lb, ub)
        lb = np.r_[np.zeros(3 * T), np.maximum(floor, 0)]
        q = np.zeros(n); q[:2 * T] = eps_qp
        return solve_qp(np.arange(3 * T, n), 2.0 * weights, q, A_ub, b_ub, A_eq, b_eq, lb, ub)

    full = np.full(T, bat["mw"])
    x1 = one_pass(full, full)
    net1 = x1[:T] - x1[T:2 * T]
    x2 = one_pass(np.where(net1 > mode_tol, bat["mw"], 0.0), np.where(net1 < -mode_tol, bat["mw"], 0.0))
    if lex is not None:
        peak_lb = floor if objective == "minmax" else np.maximum(floor, 0)
        x2 = priority_stage(objective, A_ub, b_ub, A_eq, b_eq, peak_lb, x2, baseline.max(axis=0), bat, weights, lex)
    return _unpack(x2, T, L)


# ------------------------------------------------------------ revenue (electricity price)
def optimise_revenue(price, bat, throughput_cost=0.0, mode_tol=1e-3):
    """Schedule that earns the most from the spot price (objective 'revenue', an LP).

    price           -- (T,) price per MWh, in any currency (the result is in the same currency)
    throughput_cost -- cost per MWh that passes through the battery (wear). 0 = spot price only.
    Revenue = sum_t price[t] * dt * (discharge[t] - charge[t]) - throughput_cost * dt * (d + c).

    The grid is ignored here: this is the plan a pure trader would run. Two passes, as in the
    piecewise optimiser: pass 1 is free, pass 2 locks each hour to charge / discharge / idle, so
    the model SOC equals the physical SOC and nothing is charged and discharged at once.
    Returns (discharge, charge, soc, peak) with peak an empty array (no loading in this model)."""
    price = np.asarray(price, float)
    T = len(price)
    n = 3 * T
    dt = bat["dt_h"]
    A_eq, b_eq = soc_equations(T, n, bat["mwh"], bat["eta_c"], bat["eta_d"], bat["soc_init"], dt)
    A_ub = sp.csc_matrix((0, n)); b_ub = np.zeros(0)
    c = np.zeros(n)
    c[:T] = -price * dt + throughput_cost * dt          # discharge earns, wear costs
    c[T:2 * T] = price * dt + throughput_cost * dt      # charge costs, wear costs
    lb = np.zeros(n)

    def one_pass(max_d, max_c):
        ub = np.r_[max_d, max_c, np.full(T, bat["mwh"])]
        return solve_lp(c, A_ub, b_ub, A_eq, b_eq, lb, ub)

    full = np.full(T, bat["mw"])
    x1 = one_pass(full, full)
    net1 = x1[:T] - x1[T:2 * T]
    try:
        x2 = one_pass(np.where(net1 > mode_tol, bat["mw"], 0.0), np.where(net1 < -mode_tol, bat["mw"], 0.0))
    except OptimisationError:                  # locking made it infeasible: keep the free solution
        x2 = x1
    d, ch, soc, _ = _unpack(x2, T, 0)
    return d, ch, soc, np.zeros(0)


def revenue_of(schedule, price, dt_h=1.0, throughput_cost=0.0):
    """Money earned by a net schedule (+ = discharge) at the given prices."""
    s = np.asarray(schedule, float)
    return float(np.sum(np.asarray(price, float) * s) * dt_h - throughput_cost * np.sum(np.abs(s)) * dt_h)
