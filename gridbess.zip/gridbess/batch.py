"""Data collection: one 'cell' = one green share x one strategy x one battery size.
For every cell the best node is found and the full period is then run on that node."""
import json
import time

import numpy as np

from .network import Network
from .study import Study


def green_share(spec_json, ghi_json, wind_json, settings_json):
    """Annual DER production divided by annual load energy when every generator is multiplied by 1."""
    s = dict(json.loads(settings_json)); s["der_factor"] = 1.0
    st = Study(json.loads(spec_json), np.asarray(json.loads(ghi_json), float), np.asarray(json.loads(wind_json), float), s)
    load = float((st.load_scale * st.net.load_p).sum() * st.bat["dt_h"])
    der = float((st.sgen_scale * st.net.sgen_p).sum() * st.bat["dt_h"]) if st.sgen_scale.size else 0.0
    return {"load_mwh": load, "der_mwh_at_1": der, "share_at_1": der / load if load > 0 else 0.0, "hours": int(st.T)}


def _screen_index(T, weeks, days_each):
    """Whole days from evenly spread weeks of the period, so every season is represented."""
    n_days = T // 24
    if n_days < weeks * days_each * 2:
        return None
    starts = [int(round((n_days - days_each) * (k + 0.5) / weeks)) for k in range(weeks)]
    return np.concatenate([np.arange(d * 24, (d + days_each) * 24) for d in starts])


def batch_cell(spec_json, ghi_json, wind_json, price_json, params_json, progress=None):
    t_start = time.time()
    p = json.loads(params_json)
    spec = json.loads(spec_json)
    ghi = np.asarray(json.loads(ghi_json), float); wind = np.asarray(json.loads(wind_json), float)
    price = np.asarray(json.loads(price_json), float)
    T = int(min(len(ghi), len(wind), len(price)) // 24 * 24)
    ghi, wind, price = ghi[:T], wind[:T], price[:T]
    cb = (lambda stage, frac: progress(stage, float(min(1.0, max(0.0, frac))))) if progress is not None else (lambda s, f: None)
    settings = dict(p["settings"])
    settings.update(battery_mw=float(p["mw"]), battery_mwh=float(p["mw"]) * float(p["hours"]), der_factor=float(p["der_factor"]),
                    profit_priority=True, grid_priority_pct=float(p["pct"]))
    objective = p.get("objective", "quadratic_peak")
    scr = p.get("screen") or {}
    idx = _screen_index(T, int(scr.get("weeks", 4)), int(scr.get("days_each", 7))) if scr.get("mode", "weeks") == "weeks" else None

    full = Study(spec, ghi, wind, settings, None, price)
    buses = full.net.battery_candidates()
    names = {b: full.net.bus_names[full.net.bus_pos[int(b)]] for b in buses}
    scores = {}; results = {}
    share_screen = 0.4 if idx is not None else 1.0
    if idx is not None:
        sset = dict(settings); sset["n_levels"] = int(scr.get("levels", 5))
        st = Study(spec, ghi[idx], wind[idx], sset, None, price[idx])
        for i, b in enumerate(buses):
            st.progress = lambda stage, frac, i=i, b=b: cb(f"searching node {names[b]}: {stage}", share_screen * (i + frac) / len(buses))
            r = st.run_bus(b, objective, keep_series=False)
            scores[b] = r["weighted_overload_after"]
        best = min(scores, key=scores.get)
        full.progress = lambda stage, frac: cb(f"full period on {names[best]}: {stage}", share_screen + (1 - share_screen) * frac)
        res = full.run_bus(best, objective, keep_series=False)
    else:
        for i, b in enumerate(buses):
            full.progress = lambda stage, frac, i=i, b=b: cb(f"node {names[b]}: {stage}", (i + frac) / len(buses))
            results[b] = full.run_bus(b, objective, keep_series=False)
            scores[b] = results[b]["weighted_overload_after"]
        best = min(scores, key=scores.get); res = results[best]
    before, after = res["weighted_overload_before"], res["weighted_overload_after"]
    lex = res.get("lex") or {}
    out = {
        "bus": int(best), "bus_name": names[best],
        "netvenlighed_pct": 100.0 * (1.0 - after / before) if before > 0 else 0.0,
        "indtjening": float(res.get("revenue", float("nan"))),
        "indtjening_spot": float(res.get("revenue_spot_only", float("nan"))),
        "max_loading_before_pct": res["max_loading_before_pct"], "max_loading_after_pct": res["max_loading_after_pct"],
        "cycles": res["equivalent_cycles"], "simultaneous_mwh": res["simultaneous_mwh"],
        "grid_limit_loosened_pct": lex.get("grid_limit_loosened_pct"),
        "hours": T, "screened_hours": 0 if idx is None else int(len(idx)),
        "seconds": time.time() - t_start,
    }
    return json.dumps({k: (None if isinstance(v, float) and not np.isfinite(v) else v) for k, v in out.items()})
